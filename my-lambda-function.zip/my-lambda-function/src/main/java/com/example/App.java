package com.example;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

// This class represents the expected input JSON structure
class InputData {
    private String message; // Field corresponding to the JSON input

    // Getter and Setter
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}

// Your main Lambda handler class
public class App implements RequestHandler<InputData, String> {
    @Override
    public String handleRequest(InputData input, Context context) {
        // Access the input data
        String message = input.getMessage();
        
        // Process the input and return a response
        return "Hello, " + message; // This will return "Hello, <message from input>"
    }
}
